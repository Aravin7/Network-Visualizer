var config = {
    "IPOP" : {
        "ip":"52.139.216.32",
        "port":"5000",
    },
    "React" : {
        "ip": "150.29.149.79",
        "port":"3000",
    }
}

export default config;